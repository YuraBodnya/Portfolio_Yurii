
class Controller{
  constructor(view , model){
    this.model = model;
    this.view = view;
  }
  init(){
    this.model.currentGeolocation();
    console.log(this.model)
    this.model.getData();
  }
}

class Model{
    constructor(){
        this.location = {
            lat: '',
            lon: ''
        };
        this.url = [
                'http://api.openweathermap.org/data/2.5/weather?q=Luhansk&units=metric&appid=dcf132fe522672ad08dcda4ab5ff268d'
        ];
        this.data = null;
        this.optionSearch = '';   
    }
    
    currentGeolocation(){
        navigator.geolocation.getCurrentPosition(this.success.bind(this) , this.errorLocation.bind(this) , this.options);
    }
    getData(){
        console.log(this.location); 
        console.log(this); 
    }
    success(pos){
        this.location = {
            lat: pos.coords.latitude,
            lon: pos.coords.longitude
        };
        this.optionSearch = true;
    }
    errorLocation(err){
        console.warn(`ERROR(${err.code}): ${err.message}`);
        this.optionSearch = false;
    }
}

class View{
  constructor(section){
    this.section = document.querySelector(section);
  }
}

const view = new View('#section-weather');
const model = new Model();
const controller = new Controller(view , model).init();